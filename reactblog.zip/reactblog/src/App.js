import logo from './logo.svg';
import './App.css';
import Blogclass from './components/Blogclass';
import Blogfun from './components/Blogfun';

function App() {
  return (
    <div class="App">
      <h1>Healthy plate for kids</h1>
      <Blogfun></Blogfun>
      <Blogclass></Blogclass>

    </div>
  );
}

export default App;
