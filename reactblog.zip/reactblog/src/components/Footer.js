
function Footer() {
    return (
        <>

            <h6 text-align='right'>Keep visiting this page for more updates <br></br>Author:Renuka        13-12-2022 </h6>
            {/* <br></br> */}
            {/* <p text-align='right' >Author:Renuka        13-12-2022</p> */}
            {/* <p text-align='right' >Keep visiting this page for more updates <br></br>Author:Renuka        13-12-2022 </p> */}

        </>

    )
}
export default Footer;